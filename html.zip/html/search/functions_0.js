var searchData=
[
  ['alfabeto_60',['Alfabeto',['../class_alfabeto.html#a218c7371b04d202f3c7bfbc2640f091a',1,'Alfabeto::Alfabeto()'],['../class_alfabeto.html#aae39ac6a76ff9a285e8da170ffeebd2d',1,'Alfabeto::Alfabeto(const string &amp;id, const string &amp;a)']]],
  ['anadir_5falfabeto_61',['anadir_alfabeto',['../class_cjt___alfabetos.html#a416d5aa414a67a040ad2552bfd6c7f3d',1,'Cjt_Alfabetos']]],
  ['anadir_5fmensaje_62',['anadir_mensaje',['../class_cjt___mensajes.html#a6d38ba9a1a3653d776e0e9b518abe14f',1,'Cjt_Mensajes']]]
];

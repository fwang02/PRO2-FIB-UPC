var searchData=
[
  ['cjt_5falfabetos_70',['Cjt_Alfabetos',['../class_cjt___alfabetos.html#aa837556ca24f77ba23c98f515afac70a',1,'Cjt_Alfabetos']]],
  ['cjt_5fmensajes_71',['Cjt_Mensajes',['../class_cjt___mensajes.html#a8659bed96d71c137da02125abf77ff31',1,'Cjt_Mensajes']]],
  ['cod_5fperm_72',['cod_perm',['../class_mensaje.html#aec5fdce34cae4000b0b564039b85ec6b',1,'Mensaje']]],
  ['cod_5fsust_73',['cod_sust',['../class_alfabeto.html#a8664c329302eb38082e5e6bfca304d19',1,'Alfabeto::cod_sust()'],['../class_mensaje.html#a49c2b34c9ddf4c383bf045c825ed65a5',1,'Mensaje::cod_sust()']]],
  ['consultar_74',['consultar',['../class_cjt___alfabetos.html#a4ebfc698fa4151eaed27d38cdb5c7399',1,'Cjt_Alfabetos::consultar()'],['../class_cjt___mensajes.html#acd47dff8cc35ff0156f571fbd463b2c0',1,'Cjt_Mensajes::consultar()']]],
  ['consultar_5fespecial_75',['consultar_especial',['../class_alfabeto.html#a5cfb876704783662840c53e920fe7e76',1,'Alfabeto']]],
  ['consultar_5fid_76',['consultar_id',['../class_alfabeto.html#a3e0dc7d552998cd2236a2880422504e2',1,'Alfabeto::consultar_id()'],['../class_mensaje.html#af74cefd09f8048b715dc191e2f1329df',1,'Mensaje::consultar_id()']]],
  ['consultar_5fid_5falf_77',['consultar_id_alf',['../class_mensaje.html#a19d988241ddaefbb1c6ce6a23e2e4610',1,'Mensaje']]],
  ['consultar_5fnum_5fmens_78',['consultar_num_mens',['../class_alfabeto.html#aebcc39e0ad62ccc9b8795105f30d9dc3',1,'Alfabeto']]]
];

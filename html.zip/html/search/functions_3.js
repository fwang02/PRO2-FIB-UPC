var searchData=
[
  ['dec_5fnum_5fmensajes_79',['dec_num_mensajes',['../class_alfabeto.html#ad3e2838dc0f3e55dad23b7db64b4aa1a',1,'Alfabeto::dec_num_mensajes()'],['../class_cjt___alfabetos.html#af54fb216a2fc9cd0a1b02a108c2acbfc',1,'Cjt_Alfabetos::dec_num_mensajes()']]],
  ['decod_5fperm_80',['decod_perm',['../class_mensaje.html#ab15a29b5c69128f289d8f293d2ac1479',1,'Mensaje']]],
  ['decod_5fsust_81',['decod_sust',['../class_alfabeto.html#a8cefbd6d7584ab9bae7fe34528c32468',1,'Alfabeto::decod_sust()'],['../class_mensaje.html#a1d732dcf5bdf689a36feeab191f80a4b',1,'Mensaje::decod_sust()']]]
];

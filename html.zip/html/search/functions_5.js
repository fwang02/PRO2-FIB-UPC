var searchData=
[
  ['inc_5fnum_5fmensajes_86',['inc_num_mensajes',['../class_alfabeto.html#ad2f91f1e653cdad28da7d538c7627a0c',1,'Alfabeto::inc_num_mensajes()'],['../class_cjt___alfabetos.html#a65dc5876a29b6e214188a7ce638c01ff',1,'Cjt_Alfabetos::inc_num_mensajes()']]]
];

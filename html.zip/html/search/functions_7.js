var searchData=
[
  ['main_89',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mensaje_90',['Mensaje',['../class_mensaje.html#a7b8b4ca08f400fef32eaffeec00f65b3',1,'Mensaje::Mensaje()'],['../class_mensaje.html#aa8e25c08c3836e75c426043554e4ee50',1,'Mensaje::Mensaje(const string &amp;id, const string &amp;alf_id, const string &amp;txt)'],['../class_mensaje.html#a6e1262043a946786db65b76a094ffc96',1,'Mensaje::Mensaje(const string &amp;mensaje)']]]
];
